/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.datos;

import app.datos.DatabaseConnection;
import app.entidades.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JuegoDAO {

    // Método para crear un nuevo usuario
    public boolean insertarJuego(Usuario usuario,int gana, int pierde, int puntuacion) {
        
        int contador = consultaValores(usuario.getUsu_id(), "SELECT COUNT(*) AS 'total' FROM Juego WHERE usu_id = ?") + 1;
        
        String sql = "INSERT INTO Juego (usu_id,jue_partida,jue_gana,jue_pierde,jue_puntuacion) VALUES (?, ?, ?, ? ,?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, usuario.getUsu_id());
            pstmt.setInt(2, contador);
            pstmt.setInt(3, gana);
            pstmt.setInt(4, pierde);
            pstmt.setInt(5, puntuacion);
            
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Juego creado con éxito.");
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Error al crear el juego: " + e.getMessage());
        }
        return false;
    }
    
    private int consultaValores(int usuId, String sql){
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, usuId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el contador: " + e.getMessage());
        }

        return 0;
    }
    
    public Map<String, Integer> consultarProgreso(int usu_id){        
        Map<String, Integer> resultado = new HashMap<String, Integer>();
        resultado.put("totalPartidas", consultaValores(usu_id, "SELECT COUNT(*) AS 'total' FROM Juego WHERE usu_id = ?"));
        resultado.put("totalGanadas", consultaValores(usu_id, "SELECT COUNT(*) AS 'total' FROM Juego WHERE usu_id = ? AND jue_gana = 1"));
        resultado.put("totalPerdidas", consultaValores(usu_id, "SELECT COUNT(*) AS 'total' FROM Juego WHERE usu_id = ? AND jue_pierde = 1"));
        resultado.put("totalPuntos", consultaValores(usu_id, "SELECT SUM(jue_puntuacion) AS 'total' FROM Juego WHERE usu_id = ?"));
        return resultado;
    }
    

    
}
