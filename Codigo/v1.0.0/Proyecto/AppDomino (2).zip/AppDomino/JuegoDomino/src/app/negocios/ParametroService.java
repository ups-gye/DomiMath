/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.negocios;

import app.datos.ParametroDAO;
import app.entidades.Parametro;
import java.util.List;

public class ParametroService {

    private final ParametroDAO parametroDAO;

    public ParametroService() {
        this.parametroDAO = new ParametroDAO();
    }

    // Registrar un nuevo parámetro
    public boolean registrarParametro(List<Parametro> listaParametro) {        
        for (Parametro parametro : listaParametro){            
            Parametro parametroAux = obtenerParametroPorNombre(parametro.getPar_nombre());
            if (parametroAux == null){
                parametroDAO.createParametro(parametro);
            }else{
                parametro.setPar_id(parametroAux.getPar_id());
                actualizarParametro(parametro);
            }            
        }        
        // Guardar el nuevo parámetro
        return true;
    }
    
    public List<Parametro> listarParametros(){
        return parametroDAO.getAllParametros();
    }

    // Obtener un parámetro por clave
    public Parametro obtenerParametroPorNombre(String nombre) {
        return parametroDAO.getParametroByNombre(nombre);
    }

    // Actualizar la información del parámetro
    public boolean actualizarParametro(Parametro parametro) {
        return parametroDAO.updateParametro(parametro);        
    }

    // Eliminar un parámetro por ID
    public void eliminarParametro(int id) {
        parametroDAO.deleteParametro(id);
    }

}