/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.entidades;

public class Usuario {
    private int usu_id;
    private String usu_identificacion;
    private String usu_nombre;
    private String usu_apellido;
    private String usu_correo;
    private String usu_telefono;
    private byte[] usu_foto;
    private String usu_usuario;
    private String usu_clave;
    private String usu_perfil;
    
    public Usuario(){
        
    }

    public Usuario(String usu_identificacion, String usu_nombre, String usu_apellido, String usu_correo, String usu_telefono, byte[] usu_foto, String usu_usuario, String usu_clave, String usu_perfil) {
        this.usu_identificacion = usu_identificacion;
        this.usu_nombre = usu_nombre;
        this.usu_apellido = usu_apellido;
        this.usu_correo = usu_correo;
        this.usu_telefono = usu_telefono;
        this.usu_foto = usu_foto;
        this.usu_usuario = usu_usuario;
        this.usu_clave = usu_clave;
        this.usu_perfil = usu_perfil;
    }
    
    

    // Getters y Setters
    public int getUsu_id() { return usu_id; }
    public void setUsu_id(int usu_id) { this.usu_id = usu_id; }

    public String getUsu_identificacion() { return usu_identificacion; }
    public void setUsu_identificacion(String usu_identificacion) { this.usu_identificacion = usu_identificacion; }
    
    public String getUsu_nombre() { return usu_nombre; }
    public void setUsu_nombre(String usu_nombre) { this.usu_nombre = usu_nombre; }

    public String getUsu_apellido() { return usu_apellido; }
    public void setUsu_apellido(String usu_apellido) { this.usu_apellido = usu_apellido; }

    public String getUsu_correo() { return usu_correo; }
    public void setUsu_correo(String usu_correo) { this.usu_correo = usu_correo; }

    public String getUsu_telefono() { return usu_telefono; }
    public void setUsu_telefono(String usu_telefono) { this.usu_telefono = usu_telefono; }

    public byte[] getUsu_foto() { return usu_foto; }
    public void setUsu_foto(byte[] usu_foto) { this.usu_foto = usu_foto; }

    public String getUsu_usuario() { return usu_usuario; }
    public void setUsu_usuario(String usu_usuario) { this.usu_usuario = usu_usuario; }

    public String getUsu_clave() { return usu_clave; }
    public void setUsu_clave(String usu_clave) { this.usu_clave = usu_clave; }

    public String getUsu_perfil() { return usu_perfil; }
    public void setUsu_perfil(String usu_perfil) { this.usu_perfil = usu_perfil; }
}
