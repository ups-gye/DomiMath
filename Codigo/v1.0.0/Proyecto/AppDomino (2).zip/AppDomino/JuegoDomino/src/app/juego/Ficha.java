/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.juego;

import java.io.Serializable;

/**
 *
 * @author Dirly
 */
public class Ficha implements Serializable {

    private final int multiplicando;
    private final int multiplicador;

    public Ficha(int multiplicando, int multiplicador) {
        this.multiplicando = multiplicando;
        this.multiplicador = multiplicador;
    }

    public int getMultiplicando() {
        return multiplicando;
    }

    public int getMultiplicador() {
        return multiplicador;
    }

    public int getProducto() {
        return multiplicando * multiplicador;
    }

    @Override
    public String toString() {
        return String.format("┌─────────────────┐\n"
                + "│ %2d x %2d = %4d │\n"
                + "│ %4d ÷ %2d = %2d │\n"
                + "└─────────────────┘",
                multiplicando, multiplicador, getProducto(),
                getProducto(), multiplicador, multiplicando);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Ficha ficha = (Ficha) o;
        return (multiplicando == ficha.multiplicando && multiplicador == ficha.multiplicador)
                || (multiplicando == ficha.multiplicador && multiplicador == ficha.multiplicando);
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(Math.min(multiplicando, multiplicador))
                + 31 * Integer.hashCode(Math.max(multiplicando, multiplicador));
    }
}
