/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.entidades;

public class Parametro {
    private int par_id;
    private String par_nombre;
    private String par_valor;
    
    public Parametro(){
        
    }

    public Parametro(String par_nombre, String par_valor) {
        this.par_nombre = par_nombre;
        this.par_valor = par_valor;
    }    

    // Getters y Setters
    public int getPar_id() {
        return par_id;
    }

    public void setPar_id(int par_id) {
        this.par_id = par_id;
    }

    public String getPar_nombre() {
        return par_nombre;
    }

    public void setPar_nombre(String par_nombre) {
        this.par_nombre = par_nombre;
    }

    public String getPar_valor() {
        return par_valor;
    }

    public void setPar_valor(String par_valor) {
        this.par_valor = par_valor;
    }
}
