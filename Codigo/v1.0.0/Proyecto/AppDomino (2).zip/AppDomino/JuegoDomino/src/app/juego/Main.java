/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package app.juego;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import javax.swing.SwingUtilities;

/**
 *
 * @author Dirly
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GeneradorFichas.Dificultad dificultad = GeneradorFichas.Dificultad.MEDIO;
        GeneradorFichas generador = new GeneradorFichas(dificultad);
        Set<Ficha> fichas = generador.generarFichas();

        //List<String> nombresJugadores = Arrays.asList("Jugador 1", "Jugador 2", "Jugador 3", "Jugador 4");
        List<String> nombresJugadores = Arrays.asList("Jugador 1");
        Juego juego = new Juego(nombresJugadores, fichas);
        
        juego.repartirFichas(7);

        SwingUtilities.invokeLater(() -> {
            DominoGUI gui = new DominoGUI(juego);
            gui.setVisible(true);
        });
    }
}
