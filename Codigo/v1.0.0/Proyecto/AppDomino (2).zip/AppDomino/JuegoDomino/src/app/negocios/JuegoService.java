/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.negocios;

import app.datos.JuegoDAO;
import app.entidades.Usuario;
import java.util.Map;

/**
 *
 * @author DELL
 */
public class JuegoService {
    
    private final JuegoDAO juegoDAO;

    public JuegoService() {
        this.juegoDAO = new JuegoDAO();
    }
    
    public boolean registrarResultadosJuego(Usuario usuario,int gana, int pierde, int puntuacion){
        return juegoDAO.insertarJuego(usuario, gana, pierde, puntuacion);
    }
    
    public Map<String, Integer> consultarProgreso(int usu_id){
        return juegoDAO.consultarProgreso(usu_id);
    }
}
