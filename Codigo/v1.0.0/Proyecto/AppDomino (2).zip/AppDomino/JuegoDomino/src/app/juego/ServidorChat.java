/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.juego;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Dirly
 */
public class ServidorChat {

    private static final int PUERTO = 5000;
    private Set<PrintWriter> clientesEscritores = new HashSet<>();

    public void iniciar() {
        try (ServerSocket listener = new ServerSocket(PUERTO)) {
            System.out.println("Servidor de chat iniciado...");
            while (true) {
                new ManejadorCliente(listener.accept()).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class ManejadorCliente extends Thread {

        private Socket socket;
        private PrintWriter out;

        public ManejadorCliente(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                synchronized (clientesEscritores) {
                    clientesEscritores.add(out);
                }

                String mensaje;
                while ((mensaje = in.readLine()) != null) {
                    System.out.println("Mensaje recibido: " + mensaje);
                    for (PrintWriter writer : clientesEscritores) {
                        writer.println(mensaje);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (out != null) {
                    synchronized (clientesEscritores) {
                        clientesEscritores.remove(out);
                    }
                }
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) {
        new ServidorChat().iniciar();
    }
}
