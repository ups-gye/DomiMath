/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.juego;

import app.datos.JuegoDAO;
import app.negocios.JuegoService;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 *
 * @author Dirly
 */
public class Juego implements Serializable {

    private List<Jugador> jugadores;
    private List<Ficha> fichasEnJuego;
    private List<Ficha> fichasDisponibles;
    private List<Ficha> fichasOriginales;
    private int jugadorActual;
    private boolean juegoTerminado;
    private boolean bloqueo;
    private int ronda;
    
    public Juego(Set<Ficha> todasLasFichas){
        jugadores = new ArrayList<>();        
        fichasEnJuego = new ArrayList<>();
        fichasDisponibles = new ArrayList<>(todasLasFichas);
        Collections.shuffle(fichasDisponibles);
        jugadorActual = 0;
        juegoTerminado = false;
        bloqueo = false;
        this.ronda = 1;
    }

    public Juego(List<String> nombresJugadores, Set<Ficha> todasLasFichas) {
        jugadores = new ArrayList<>();
        for (String nombre : nombresJugadores) {
            jugadores.add(new Jugador(nombre, null));
        }
        fichasEnJuego = new ArrayList<>();
        fichasDisponibles = new ArrayList<>(todasLasFichas);
        Collections.shuffle(fichasDisponibles);
        jugadorActual = 0;
        juegoTerminado = false;
        bloqueo = false;

        this.ronda = 1;
    }
    
    public void agregarJugador(Jugador jugador) {
        if (jugadores.size() < 4) { // Supongamos que el máximo es 4 jugadores
            jugadores.add(jugador);
        } else {
            throw new IllegalStateException("No se pueden agregar más de 4 jugadores");
        }
    }

    public void repartirFichas(int fichasPorJugador) {
        for (int i = 0; i < fichasPorJugador; i++) {
            for (Jugador jugador : jugadores) {
                if (!fichasDisponibles.isEmpty()) {
                    jugador.agregarFicha(fichasDisponibles.remove(0));
                }
            }
        }
    }

    public boolean esJugadaValida(Ficha ficha) {
        if (fichasEnJuego.isEmpty()) {
            return true;
        }
        Ficha primeraFicha = fichasEnJuego.get(0);
        Ficha ultimaFicha = fichasEnJuego.get(fichasEnJuego.size() - 1);
        return ficha.getProducto() == primeraFicha.getProducto()
                || ficha.getProducto() == ultimaFicha.getProducto()
                || ficha.getMultiplicando() == primeraFicha.getMultiplicando()
                || ficha.getMultiplicando() == ultimaFicha.getMultiplicando()
                || ficha.getMultiplicador() == primeraFicha.getMultiplicador()
                || ficha.getMultiplicador() == ultimaFicha.getMultiplicador();
    }

    public void jugarFicha(int indiceFicha) {
        Jugador jugadorActual = jugadores.get(this.jugadorActual);
        Ficha fichaJugada = jugadorActual.jugarFicha(indiceFicha);

        if (fichasEnJuego.isEmpty() || fichaJugada.getProducto() == fichasEnJuego.get(0).getProducto()
                || fichaJugada.getMultiplicando() == fichasEnJuego.get(0).getMultiplicando()
                || fichaJugada.getMultiplicador() == fichasEnJuego.get(0).getMultiplicador()) {
            fichasEnJuego.add(0, fichaJugada);
        } else {
            fichasEnJuego.add(fichaJugada);
        }

        System.out.println(jugadorActual.getNombre() + " jugó: " + fichaJugada);

        if (!jugadorActual.tieneFichas()) {
            juegoTerminado = true;
            System.out.println("¡" + jugadorActual.getNombre() + " ha ganado!");
        } else {
            pasarTurno();
        }
    }

    public void pasarTurno() {
        jugadorActual = (jugadorActual + 1) % jugadores.size();
    }

    public boolean puedejugar(Jugador jugador) {
        for (Ficha ficha : jugador.getFichas()) {
            if (esJugadaValida(ficha)) {
                return true;
            }
        }
        return false;
    }

    public void verificarBloqueo() {
        bloqueo = true;
        for (Jugador jugador : jugadores) {
            if (puedejugar(jugador)) {
                bloqueo = false;
                break;
            }
        }
        if (bloqueo) {
            juegoTerminado = true;
            System.out.println("¡El juego ha terminado por bloqueo!");
        }
    }

    public Jugador getJugadorActual() {
        return jugadores.get(jugadorActual);
    }

    public List<Ficha> getFichasEnJuego() {
        return fichasEnJuego;
    }

    public boolean juegoTerminado() {
        return juegoTerminado;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Estado del juego:\n");
        for (Jugador jugador : jugadores) {
            sb.append(jugador).append("\n");
        }
        sb.append("Fichas en juego: ").append(fichasEnJuego);
        return sb.toString();
    }

    public void finalizarRonda() {
        Jugador ganador = null;
        int puntuacionRonda = 0;

        for (Jugador jugador : jugadores) {
            int puntuacionJugador = jugador.calcularPuntuacionFichasRestantes();
            puntuacionRonda += puntuacionJugador;
            if (ganador == null || puntuacionJugador < ganador.calcularPuntuacionFichasRestantes()) {
                ganador = jugador;
            }
        }

        ganador.agregarPuntuacion(puntuacionRonda);
        System.out.println("Fin de la ronda " + ronda + ". Ganador: " + ganador.getNombre()
                + " (+" + puntuacionRonda + " puntos)");
        
        JuegoService juegoService = new JuegoService();
        //Capturo Resultados
        if (ganador != null && ganador.getUsuario() != null){
            juegoService.registrarResultadosJuego(ganador.getUsuario(), 1, 0, puntuacionRonda);
        }else{
            for (Jugador jugador : jugadores){
                if (jugador.getUsuario() != null){
                    juegoService.registrarResultadosJuego(ganador.getUsuario(), 0, 1, 0);
                }
            }
        }

        ronda++;
        reiniciarJuego();
    }

    private void reiniciarJuego() {
        for (Jugador jugador : jugadores) {
            jugador.getFichas().clear();
        }
        fichasEnJuego.clear();
        fichasDisponibles = new ArrayList<>(fichasOriginales);
        Collections.shuffle(fichasDisponibles);
        juegoTerminado = false;
        bloqueo = false;
        repartirFichas(7);
    }

    public boolean hayGanadorFinal(int puntuacionObjetivo) {
        return jugadores.stream().anyMatch(j -> j.getPuntuacion() >= puntuacionObjetivo);
    }

    public Jugador obtenerGanadorFinal() {
        return jugadores.stream().max(Comparator.comparingInt(Jugador::getPuntuacion)).orElse(null);
    }
    
    public void guardarPartida(String nombreArchivo) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(nombreArchivo))) {
            out.writeObject(this);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Juego cargarPartida(String nombreArchivo) {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(nombreArchivo))) {
            return (Juego) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}
