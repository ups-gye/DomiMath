/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.datos;

import app.datos.DatabaseConnection;
import app.entidades.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    // Método para crear un nuevo usuario
    public boolean createUsuario(Usuario usuario) {
        String sql = "INSERT INTO Usuario (usu_identificacion, usu_nombre, usu_apellido, usu_correo, usu_telefono, usu_foto, usu_usuario, usu_clave, usu_perfil) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, usuario.getUsu_identificacion());
            pstmt.setString(2, usuario.getUsu_nombre());
            pstmt.setString(3, usuario.getUsu_apellido());
            pstmt.setString(4, usuario.getUsu_correo());
            pstmt.setString(5, usuario.getUsu_telefono());
            pstmt.setBytes(6, usuario.getUsu_foto());
            pstmt.setString(7, usuario.getUsu_usuario());
            pstmt.setString(8, usuario.getUsu_clave());
            pstmt.setString(9, usuario.getUsu_perfil());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Usuario creado con éxito.");
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Error al crear el usuario: " + e.getMessage());
        }
        return false;
    }

    // Método para obtener un usuario por ID
    public Usuario getUsuarioByIdentificacion(String identificacion) {
        String sql = "SELECT * FROM Usuario WHERE usu_identificacion = ?";
        Usuario usuario = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, identificacion);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                usuario = new Usuario();
                usuario.setUsu_id(rs.getInt("usu_id"));
                usuario.setUsu_identificacion(rs.getString("usu_identificacion").trim());
                usuario.setUsu_nombre(rs.getString("usu_nombre").trim());
                usuario.setUsu_apellido(rs.getString("usu_apellido").trim());
                usuario.setUsu_correo(rs.getString("usu_correo").trim());
                usuario.setUsu_telefono(rs.getString("usu_telefono").trim());
                usuario.setUsu_foto(rs.getBytes("usu_foto"));
                usuario.setUsu_usuario(rs.getString("usu_usuario").trim());
                usuario.setUsu_clave(rs.getString("usu_clave").trim());
                usuario.setUsu_perfil(rs.getString("usu_perfil").trim());
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el usuario: " + e.getMessage());
        }

        return usuario;
    }

    // Método para obtener todos los usuarios
    public List<Usuario> getAllUsuarios() {
        String sql = "SELECT * FROM Usuario";
        List<Usuario> usuarios = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setUsu_id(rs.getInt("usu_id"));
                usuario.setUsu_identificacion(rs.getString("usu_identificacion").trim());
                usuario.setUsu_nombre(rs.getString("usu_nombre").trim());
                usuario.setUsu_apellido(rs.getString("usu_apellido").trim());
                usuario.setUsu_correo(rs.getString("usu_correo").trim());
                usuario.setUsu_telefono(rs.getString("usu_telefono").trim());
                usuario.setUsu_foto(rs.getBytes("usu_foto"));
                usuario.setUsu_usuario(rs.getString("usu_usuario").trim());
                usuario.setUsu_clave(rs.getString("usu_clave").trim());
                usuario.setUsu_perfil(rs.getString("usu_perfil").trim());

                usuarios.add(usuario);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener los usuarios: " + e.getMessage());
        }

        return usuarios;
    }

    // Método para actualizar un usuario
    public boolean updateUsuario(Usuario usuario) {
        String sql = "UPDATE Usuario SET usu_identificacion = ?, usu_nombre = ?, usu_apellido = ?, usu_correo = ?, usu_telefono = ?, usu_foto = ?, usu_usuario = ?, usu_clave = ?, usu_perfil = ? WHERE usu_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, usuario.getUsu_identificacion());
            pstmt.setString(2, usuario.getUsu_nombre());
            pstmt.setString(3, usuario.getUsu_apellido());
            pstmt.setString(4, usuario.getUsu_correo());
            pstmt.setString(5, usuario.getUsu_telefono());
            pstmt.setBytes(6, usuario.getUsu_foto());
            pstmt.setString(7, usuario.getUsu_usuario());
            pstmt.setString(8, usuario.getUsu_clave());
            pstmt.setString(9, usuario.getUsu_perfil());
            pstmt.setInt(10, usuario.getUsu_id());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Usuario actualizado con éxito.");
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar el usuario: " + e.getMessage());
        }
        return false;
    }

    // Método para eliminar un usuario por ID
    public void deleteUsuario(int id) {
        String sql = "DELETE FROM Usuario WHERE usu_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Usuario eliminado con éxito.");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar el usuario: " + e.getMessage());
        }
    }
    
    // Obtener un usuario por su nombre de usuario
    public Usuario getUsuarioByUsername(String username) {
        String sql = "SELECT * FROM Usuario WHERE usu_usuario = ?";
        Usuario usuario = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                usuario = new Usuario();
                usuario.setUsu_id(rs.getInt("usu_id"));
                usuario.setUsu_identificacion(rs.getString("usu_identificacion").trim());
                usuario.setUsu_nombre(rs.getString("usu_nombre").trim());
                usuario.setUsu_apellido(rs.getString("usu_apellido").trim());
                usuario.setUsu_correo(rs.getString("usu_correo").trim());
                usuario.setUsu_telefono(rs.getString("usu_telefono").trim());
                usuario.setUsu_foto(rs.getBytes("usu_foto"));
                usuario.setUsu_usuario(rs.getString("usu_usuario").trim());
                usuario.setUsu_clave(rs.getString("usu_clave").trim());
                usuario.setUsu_perfil(rs.getString("usu_perfil").trim());
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el usuario por nombre de usuario: " + e.getMessage());
        }

        return usuario;
    }
}
