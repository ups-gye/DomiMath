/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package app.juego;

import app.entidades.Usuario;
import java.util.Set;

/**
 *
 * @author DELL
 */
public class MainJ_CPU {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        GeneradorFichas.Dificultad dificultad = GeneradorFichas.Dificultad.FACIL;
        GeneradorFichas generador = new GeneradorFichas(dificultad);
        Set<Ficha> fichas = generador.generarFichas();
        
        Juego juego = new Juego(fichas);
        juego.agregarJugador(new Jugador("Humano", new Usuario()));
        juego.agregarJugador(new JugadorComputadora("Computadora", 1));

        juego.repartirFichas(4);
        
        // Inicializa la interfaz gráfica
        DominoGUI gui = new DominoGUI(juego);
        gui.setVisible(true);
    }

}
