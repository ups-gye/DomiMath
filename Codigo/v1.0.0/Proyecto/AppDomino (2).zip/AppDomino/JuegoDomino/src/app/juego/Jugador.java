/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.juego;

import app.entidades.Usuario;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Dirly
 */
public class Jugador implements Serializable {

    private String nombre;
    private List<Ficha> fichas;
    private int puntuacion;
    private Usuario usuario;

    public Jugador(String nombre, Usuario usuario) {
        this.nombre = nombre;
        this.fichas = new ArrayList<>();
        this.puntuacion = 0;
        this.usuario = usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public List<Ficha> getFichas() {
        return fichas;
    }

    public void agregarFicha(Ficha ficha) {
        fichas.add(ficha);
    }

    public boolean tieneFichas() {
        return !fichas.isEmpty();
    }

    public Ficha jugarFicha(int indice) {
        return fichas.remove(indice);
    }

    public int calcularPuntuacionFichasRestantes() {
        return fichas.stream().mapToInt(Ficha::getProducto).sum();
    }

    public void agregarPuntuacion(int puntos) {
        this.puntuacion += puntos;
    }

    public int getPuntuacion() {
        return puntuacion;
    }
    
    /**
     * @return the usuario
     */
    public Usuario getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public String toString() {
        return nombre + " (Fichas: " + fichas.size() + ", Puntuación: " + puntuacion + ")";
    }
}
