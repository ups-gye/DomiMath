/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.juego;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/**
 *
 * @author Dirly
 */
public class DominoGUI extends JFrame {

    private Juego juego;
    private JPanel panelMesa;
    private JPanel panelMano;
    private JLabel labelTurno;
    private JButton botonPasar;
    private JButton botonRendirse;
    private JButton botonAyuda;

    private JTextArea areaChat;
    private JTextField campoMensaje;
    private PrintWriter out;
    private BufferedReader in;

    private AudioManager audioManager;

    public DominoGUI(Juego juego) {
        this.juego = juego;
        setTitle("Dominó de Multiplicación y División");
        setSize(1000, 700);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        crearPanelMesa();
        crearPanelMano();
        crearPanelControl();

        actualizarInterfaz();

        crearPanelChat();
        conectarAlServidor();

        audioManager = new AudioManager();
        audioManager.playBackgroundMusic("D:\\DIRLY CAICEDO\\Descargas\\SD_ALERT_29.mp3");
    }

    private void crearPanelMesa() {
        panelMesa = new JPanel();
        panelMesa.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelMesa.setBackground(new Color(0, 100, 0));  // Verde oscuro
        panelMesa.setBorder(BorderFactory.createTitledBorder("Mesa de Juego"));
        add(new JScrollPane(panelMesa), BorderLayout.CENTER);
    }

    private void crearPanelMano() {
        panelMano = new JPanel();
        panelMano.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelMano.setBackground(new Color(200, 200, 200));  // Gris claro
        panelMano.setBorder(BorderFactory.createTitledBorder("Tu Mano"));
        add(panelMano, BorderLayout.SOUTH);
    }

    private void crearPanelControl() {
        JPanel panelControl = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));

        labelTurno = new JLabel("Turno de: ");
        panelControl.add(labelTurno);

        botonPasar = new JButton("Pasar");
        botonPasar.addActionListener(e -> pasarTurno());
        panelControl.add(botonPasar);

        botonRendirse = new JButton("Rendirse");
        botonRendirse.addActionListener(e -> rendirse());
        panelControl.add(botonRendirse);

        botonAyuda = new JButton("Ayuda");
        botonAyuda.addActionListener(e -> mostrarAyuda());
        panelControl.add(botonAyuda);

        JButton botonGuardar = new JButton("Guardar Partida");
        botonGuardar.addActionListener(e -> guardarPartida());
        panelControl.add(botonGuardar);

        JButton botonCargar = new JButton("Cargar Partida");
        botonCargar.addActionListener(e -> cargarPartida());
        panelControl.add(botonCargar);

        add(panelControl, BorderLayout.NORTH);

    }

    private void actualizarInterfaz() {
        actualizarMesa();
        actualizarMano();
        actualizarTurno();
    }

    private void actualizarMesa() {
        panelMesa.removeAll();
        JPanel fichasJugadas = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 5));
        for (Ficha ficha : juego.getFichasEnJuego()) {
            fichasJugadas.add(crearBotonFicha(ficha, false));
        }
        JScrollPane scrollPane = new JScrollPane(fichasJugadas);
        scrollPane.setPreferredSize(new Dimension(panelMesa.getWidth(), 150));
        panelMesa.add(scrollPane);
        panelMesa.revalidate();
        panelMesa.repaint();
    }

    private void actualizarMano() {
        panelMano.removeAll();
        Jugador jugadorActual = juego.getJugadorActual();
        for (Ficha ficha : jugadorActual.getFichas()) {
            JButton botonFicha = crearBotonFicha(ficha, true);
            botonFicha.addActionListener(e -> jugarFicha(ficha));
            panelMano.add(botonFicha);
        }
        panelMano.revalidate();
        panelMano.repaint();
    }

    private void actualizarTurno() {
        labelTurno.setText("Turno de: " + juego.getJugadorActual().getNombre());
        botonPasar.setEnabled(!juego.puedejugar(juego.getJugadorActual()));
    }

    private JButton crearBotonFicha(Ficha ficha, boolean enMano) {
        JButton boton = new JButton() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Dibujar el fondo de la ficha
                g2d.setColor(new Color(255, 253, 208));
                g2d.fillRoundRect(2, 2, getWidth() - 4, getHeight() - 4, 10, 10);

                // Dibujar el borde de la ficha
                g2d.setColor(Color.BLACK);
                g2d.setStroke(new BasicStroke(2));
                g2d.drawRoundRect(2, 2, getWidth() - 4, getHeight() - 4, 10, 10);

                // Dibujar la línea divisoria
                g2d.drawLine(2, getHeight() / 2, getWidth() - 2, getHeight() / 2);

                // Dibujar los números
                g2d.setFont(new Font("Arial", Font.BOLD, 16));
                g2d.drawString(ficha.getMultiplicando() + " x " + ficha.getMultiplicador(), 10, getHeight() / 4 + 5);
                g2d.drawString(String.valueOf(ficha.getProducto()), 10, 3 * getHeight() / 4 + 5);
            }
        };
        boton.setPreferredSize(new Dimension(80, 120));
        boton.setEnabled(enMano);
        return boton;
    }

    private void jugarFicha(Ficha ficha) {
        if (juego.esJugadaValida(ficha)) {
            JButton botonFicha = crearBotonFicha(ficha, false);
            Point inicio = new Point(panelMano.getLocation());
            Point fin = new Point(panelMesa.getLocation());
            fin.translate(panelMesa.getWidth() / 2, panelMesa.getHeight() / 2);

            animarFicha(botonFicha, inicio, fin, () -> {
                int indiceFicha = juego.getJugadorActual().getFichas().indexOf(ficha);
                juego.jugarFicha(indiceFicha);
                notificarJugada(juego.getJugadorActual(), ficha);
                actualizarInterfaz();
                if (juego.juegoTerminado()) {
                    mostrarMensajeEnChat("¡Juego terminado! Ganador: " + juego.getJugadorActual().getNombre());
                    juego.finalizarRonda();
                    actualizarInterfaz();
                } else {
                    // Jugar el turno de la computadora si es necesario
                    SwingUtilities.invokeLater(this::jugarTurnoComputadora);
                }
            });
        } else {
            JOptionPane.showMessageDialog(this, "Jugada no válida", "Error", JOptionPane.ERROR_MESSAGE);
            audioManager.playEffect("ruta/a/tu/efecto/de/error.wav");
        }
    }

    private void animarFicha(JButton botonFicha, Point inicio, Point fin, Runnable onComplete) {
        JLayeredPane layeredPane = getLayeredPane();
        layeredPane.add(botonFicha, JLayeredPane.DRAG_LAYER);
        botonFicha.setBounds(inicio.x, inicio.y, botonFicha.getPreferredSize().width, botonFicha.getPreferredSize().height);

        Timer timer = new Timer(16, null);
        final int duracion = 500; // milisegundos
        final long startTime = System.currentTimeMillis();

        timer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                long duration = System.currentTimeMillis() - startTime;
                float progress = Math.min(1f, (float) duration / duracion);

                int x = (int) (inicio.x + (fin.x - inicio.x) * progress);
                int y = (int) (inicio.y + (fin.y - inicio.y) * progress);

                botonFicha.setLocation(x, y);

                if (progress == 1f) {
                    timer.stop();
                    layeredPane.remove(botonFicha);
                    layeredPane.repaint();
                    onComplete.run();
                }
            }
        });

        timer.start();
    }

    private void pasarTurno() {
        juego.pasarTurno();
        actualizarInterfaz();
    }

    private void rendirse() {
        int opcion = JOptionPane.showConfirmDialog(this, "¿Estás seguro de que quieres rendirte?",
                "Confirmar rendición", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            juego.finalizarRonda();
            actualizarInterfaz();
        }
    }

    private void mostrarAyuda() {
        JDialog dialogoAyuda = new JDialog(this, "Tabla de Multiplicar", true);
        dialogoAyuda.setSize(400, 400);
        dialogoAyuda.setLayout(new GridLayout(11, 11));

        // Agregar encabezados
        dialogoAyuda.add(new JLabel(""));
        for (int i = 1; i <= 10; i++) {
            dialogoAyuda.add(new JLabel(String.valueOf(i), SwingConstants.CENTER));
        }

        // Agregar filas
        for (int i = 1; i <= 10; i++) {
            dialogoAyuda.add(new JLabel(String.valueOf(i), SwingConstants.CENTER));
            for (int j = 1; j <= 10; j++) {
                dialogoAyuda.add(new JLabel(String.valueOf(i * j), SwingConstants.CENTER));
            }
        }

        dialogoAyuda.setLocationRelativeTo(this);
        dialogoAyuda.setVisible(true);
    }

    private void crearPanelChat() {
        JPanel panelChat = new JPanel(new BorderLayout());
        areaChat = new JTextArea(10, 30);
        areaChat.setEditable(false);
        panelChat.add(new JScrollPane(areaChat), BorderLayout.CENTER);

        campoMensaje = new JTextField(20);
        JButton botonEnviar = new JButton("Enviar");
        botonEnviar.addActionListener(e -> enviarMensaje());

        JPanel panelEnvio = new JPanel(new BorderLayout());
        panelEnvio.add(campoMensaje, BorderLayout.CENTER);
        panelEnvio.add(botonEnviar, BorderLayout.EAST);

        panelChat.add(panelEnvio, BorderLayout.SOUTH);
        add(panelChat, BorderLayout.EAST);
    }

    private void conectarAlServidor() {
        String servidor = "localhost";
        int puerto = 5000;
        try {
            Socket socket = new Socket(servidor, puerto);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            new Thread(() -> {
                try {
                    String mensaje;
                    while ((mensaje = in.readLine()) != null) {
                        String mensajeFinal = mensaje;
                        SwingUtilities.invokeLater(() -> areaChat.append(mensajeFinal + "\n"));
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void enviarMensaje() {
        String mensaje = campoMensaje.getText();
        if (!mensaje.isEmpty()) {
            out.println(juego.getJugadorActual().getNombre() + ": " + mensaje);
            campoMensaje.setText("");
        }
    }

    private void mostrarMensajeEnChat(String mensaje) {
        SwingUtilities.invokeLater(() -> {
            areaChat.append(mensaje + "\n");
            areaChat.setCaretPosition(areaChat.getDocument().getLength());
        });
    }

// Llamar a este método después de cada jugada
    private void notificarJugada(Jugador jugador, Ficha ficha) {
        String mensaje = jugador.getNombre() + " jugó: " + ficha.getMultiplicando() + "x" + ficha.getMultiplicador();
        mostrarMensajeEnChat(mensaje);
        out.println(mensaje);
    }

    private void jugarTurnoComputadora() { //método para manejar el turno del jugador computadora
        if (juego.getJugadorActual() instanceof JugadorComputadora) {
            JugadorComputadora computadora = (JugadorComputadora) juego.getJugadorActual();
            Ficha fichaElegida = computadora.elegirFicha(juego.getFichasEnJuego());

            if (fichaElegida != null) {
                int indiceFicha = computadora.getFichas().indexOf(fichaElegida);
                juego.jugarFicha(indiceFicha);
                notificarJugada(computadora, fichaElegida);
                actualizarInterfaz();
            } else {
                juego.pasarTurno();
                mostrarMensajeEnChat(computadora.getNombre() + " pasó su turno.");
                actualizarInterfaz();
            }

            // Verificar si el juego ha terminado
            if (juego.juegoTerminado()) {
                mostrarMensajeEnChat("¡Juego terminado! Ganador: " + juego.getJugadorActual().getNombre());
                juego.finalizarRonda();
                actualizarInterfaz();
            } else {
                // Si el siguiente jugador también es una computadora, jugar su turno
                SwingUtilities.invokeLater(this::jugarTurnoComputadora);
            }
        }
    }

    private void guardarPartida() {
        JFileChooser fileChooser = new JFileChooser();
        int resultado = fileChooser.showSaveDialog(this);

        if (resultado == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            // Usa el nombre del archivo con extensión para guardar
            String nombreArchivo = archivo.getAbsolutePath();
            juego.guardarPartida(nombreArchivo);
            JOptionPane.showMessageDialog(this, "Partida guardada correctamente.");
        }
    }

    private void cargarPartida() {
        JFileChooser fileChooser = new JFileChooser();
        int resultado = fileChooser.showOpenDialog(this);

        if (resultado == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            // Usa el nombre del archivo con extensión para cargar
            String nombreArchivo = archivo.getAbsolutePath();
            Juego juegoCargado = Juego.cargarPartida(nombreArchivo);
            if (juegoCargado != null) {
                juego = juegoCargado;
                JOptionPane.showMessageDialog(this, "Partida cargada correctamente.");
                actualizarInterfaz();
            } else {
                JOptionPane.showMessageDialog(this, "Error al cargar la partida.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

}
