/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.juego;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Dirly
 */
public class GeneradorFichas implements Serializable {

    public enum Dificultad {
        FACIL(2, 6),
        MEDIO(2, 10),
        DIFICIL(2, 12);

        private final int min;
        private final int max;

        Dificultad(int min, int max) {
            this.min = min;
            this.max = max;
        }
    }

    private Dificultad dificultad;

    public GeneradorFichas(Dificultad dificultad) {
        this.dificultad = dificultad;
    }

    public Set<Ficha> generarFichas() {
        Set<Ficha> fichas = new HashSet<>();
        for (int i = dificultad.min; i <= dificultad.max; i++) {
            for (int j = i; j <= dificultad.max; j++) {
                fichas.add(new Ficha(i, j));
            }
        }
        return fichas;
    }
}
