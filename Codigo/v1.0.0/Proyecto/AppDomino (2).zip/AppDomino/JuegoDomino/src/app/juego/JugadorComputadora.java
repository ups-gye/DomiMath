/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.juego;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 *
 * @author Dirly
 */
public class JugadorComputadora extends Jugador implements Serializable {

    private Random random = new Random();
    private int dificultad; // 1: Fácil, 2: Medio, 3: Difícil
    private int i;

    public JugadorComputadora(String nombre, int dificultad) {
        super(nombre, null);
        this.dificultad = dificultad;
    }

    public Ficha elegirFicha(List<Ficha> fichasEnJuego) {
        List<Ficha> fichasValidas = getFichas().stream()
                .filter(f -> esJugadaValida(f, fichasEnJuego))
                .collect(Collectors.toList());

        if (fichasValidas.isEmpty()) {
            return null;
        }

        switch (dificultad) {
            case 1: // Fácil: elige una ficha aleatoria
                return fichasValidas.get(random.nextInt(fichasValidas.size()));
            case 2: // Medio: elige la ficha con el valor más alto
                return fichasValidas.stream()
                        .max(Comparator.comparingInt(Ficha::getProducto))
                        .orElse(fichasValidas.get(0));
            case 3: // Difícil: elige la ficha que deja menos opciones al oponente
                return fichasValidas.stream()
                        .min(Comparator.comparingInt(f -> contarFichasValidasOponente(f, fichasEnJuego)))
                        .orElse(fichasValidas.get(0));
            default:
                return fichasValidas.get(0);
        }
    }

    private boolean esJugadaValida(Ficha ficha, List<Ficha> fichasEnJuego) {
        if (fichasEnJuego.isEmpty()) {
            return true;
        }
        Ficha primeraFicha = fichasEnJuego.get(0);
        Ficha ultimaFicha = fichasEnJuego.get(fichasEnJuego.size() - 1);
        return ficha.getProducto() == primeraFicha.getProducto()
                || ficha.getProducto() == ultimaFicha.getProducto()
                || ficha.getMultiplicando() == primeraFicha.getMultiplicando()
                || ficha.getMultiplicando() == ultimaFicha.getMultiplicando()
                || ficha.getMultiplicador() == primeraFicha.getMultiplicador()
                || ficha.getMultiplicador() == ultimaFicha.getMultiplicador();
    }

    private int contarFichasValidasOponente(Ficha fichaJugada, List<Ficha> fichasEnJuego) {
        List<Ficha> nuevasFichasEnJuego = new ArrayList<>(fichasEnJuego);
        nuevasFichasEnJuego.add(fichaJugada);
        // Asumimos un número promedio de fichas del oponente
        return (int) IntStream.range(1, 11)
                .flatMap(i -> IntStream.range(i, 11))
                .mapToObj(j -> new Ficha(i, j))
                .filter(f -> esJugadaValida(f, nuevasFichasEnJuego))
                .count();
    }
}
