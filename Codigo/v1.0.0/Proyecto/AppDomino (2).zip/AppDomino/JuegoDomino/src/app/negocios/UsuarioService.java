/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.negocios;

import app.datos.UsuarioDAO;
import app.entidades.Usuario;
import java.util.Optional;

public class UsuarioService {

    private final UsuarioDAO usuarioDAO;

    public UsuarioService() {
        this.usuarioDAO = new UsuarioDAO();
    }

    // Registrar un nuevo usuario
    public boolean registrarUsuario(Usuario usuario) {
        // Verificar si el nombre de usuario ya existe
        Usuario usuarioExistente = usuarioDAO.getUsuarioByIdentificacion(usuario.getUsu_identificacion());
        if (usuarioExistente != null) {
            System.out.println("El nombre de usuario ya está en uso.");
            return false;
        }

        // Cifrar la contraseña antes de guardarla
        String hashedPassword = cifrarClave(usuario.getUsu_clave());
        usuario.setUsu_clave(hashedPassword);

        return usuarioDAO.createUsuario(usuario);
    }

    // Autenticar usuario
    public Usuario autenticarUsuario(String usuario, String clave) {
        Usuario usuarioDB = usuarioDAO.getUsuarioByUsername(usuario);

        if (usuarioDB != null && verificarClave(clave, usuarioDB.getUsu_clave())) {
            System.out.println("Autenticación exitosa.");
            return usuarioDB;
        }

        System.out.println("Autenticación fallida.");
        return null;
    }

    // Actualizar la información del usuario
    public boolean actualizarUsuario(Usuario usuario) {
        // Opcional: Verificar que la contraseña actual sea correcta antes de permitir la actualización
        String hashedPassword = cifrarClave(usuario.getUsu_clave());
        usuario.setUsu_clave(hashedPassword);
        return usuarioDAO.updateUsuario(usuario);        
    }

    // Eliminar un usuario por ID
    public void eliminarUsuario(int id) {
        usuarioDAO.deleteUsuario(id);
    }

    // Cifrar la contraseña
    private String cifrarClave(String clave) {        
        return CifradoSimple.cifrar(clave);
    }

    // Verificar la contraseña cifrada
    private boolean verificarClave(String claveIngresada, String claveAlmacenada) {        
        return cifrarClave(claveIngresada).equals(claveAlmacenada);
    }
}
