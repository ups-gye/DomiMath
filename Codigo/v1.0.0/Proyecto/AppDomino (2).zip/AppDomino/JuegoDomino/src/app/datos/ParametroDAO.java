/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.datos;

import app.entidades.Parametro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ParametroDAO {

    // Método para crear un nuevo parámetro
    public boolean createParametro(Parametro parametro) {
        String sql = "INSERT INTO Parametro (par_nombre, par_valor) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, parametro.getPar_nombre());
            pstmt.setString(2, parametro.getPar_valor());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Parámetro creado con éxito.");
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Error al crear el parámetro: " + e.getMessage());
        }
        return false;
    }

    // Método para obtener un parámetro por ID
    public Parametro getParametroByNombre(String nombre) {
        String sql = "SELECT * FROM Parametro WHERE par_nombre = ?";
        Parametro parametro = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, nombre);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                parametro = new Parametro();
                parametro.setPar_id(rs.getInt("par_id"));
                parametro.setPar_nombre(rs.getString("par_nombre").trim());
                parametro.setPar_valor(rs.getString("par_valor").trim());
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el parámetro: " + e.getMessage());
        }

        return parametro;
    }

    // Método para obtener todos los parámetros
    public List<Parametro> getAllParametros() {
        String sql = "SELECT * FROM Parametro";
        List<Parametro> parametros = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Parametro parametro = new Parametro();
                parametro.setPar_id(rs.getInt("par_id"));
                parametro.setPar_nombre(rs.getString("par_nombre").trim());
                parametro.setPar_valor(rs.getString("par_valor").trim());

                parametros.add(parametro);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener los parámetros: " + e.getMessage());
        }

        return parametros;
    }

    // Método para actualizar un parámetro
    public boolean updateParametro(Parametro parametro) {
        String sql = "UPDATE Parametro SET par_nombre = ?, par_valor = ? WHERE par_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, parametro.getPar_nombre());
            pstmt.setString(2, parametro.getPar_valor());
            pstmt.setInt(3, parametro.getPar_id());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Parámetro actualizado con éxito.");
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar el parámetro: " + e.getMessage());
        }
        return false;
    }

    // Método para eliminar un parámetro por ID
    public void deleteParametro(int id) {
        String sql = "DELETE FROM Parametro WHERE par_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Parámetro eliminado con éxito.");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar el parámetro: " + e.getMessage());
        }
    }
}