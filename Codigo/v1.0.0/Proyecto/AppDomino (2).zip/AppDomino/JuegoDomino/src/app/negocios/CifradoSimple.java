/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.negocios;

public class CifradoSimple {

    private static final int DESPLAZAMIENTO = 3;  // Número de posiciones a desplazar en el cifrado

    // Método para cifrar un texto
    public static String cifrar(String texto) {
        StringBuilder textoCifrado = new StringBuilder();

        for (char caracter : texto.toCharArray()) {
            if (Character.isLetter(caracter)) {
                char base = Character.isUpperCase(caracter) ? 'A' : 'a';
                char caracterCifrado = (char) ((caracter - base + DESPLAZAMIENTO) % 26 + base);
                textoCifrado.append(caracterCifrado);
            } else {
                textoCifrado.append(caracter);  // No se cifran los caracteres que no son letras
            }
        }

        return textoCifrado.toString();
    }

    // Método para descifrar un texto
    public static String descifrar(String textoCifrado) {
        StringBuilder textoDescifrado = new StringBuilder();

        for (char caracter : textoCifrado.toCharArray()) {
            if (Character.isLetter(caracter)) {
                char base = Character.isUpperCase(caracter) ? 'A' : 'a';
                char caracterDescifrado = (char) ((caracter - base - DESPLAZAMIENTO + 26) % 26 + base);
                textoDescifrado.append(caracterDescifrado);
            } else {
                textoDescifrado.append(caracter);  // No se descifran los caracteres que no son letras
            }
        }

        return textoDescifrado.toString();
    }
}
